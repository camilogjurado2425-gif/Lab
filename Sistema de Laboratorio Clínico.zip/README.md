
  # Sistema de Laboratorio Clínico

  This is a code bundle for Sistema de Laboratorio Clínico. The original project is available at https://www.figma.com/design/tGuIJFah6Z9FfukMrNe10w/Sistema-de-Laboratorio-Cl%C3%ADnico.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  